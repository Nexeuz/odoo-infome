This gives the profitability by calculating the difference between the Unit Price and Cost Price.
